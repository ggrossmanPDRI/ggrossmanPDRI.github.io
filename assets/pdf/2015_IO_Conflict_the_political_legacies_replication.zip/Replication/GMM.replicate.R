############################################
# Grossman 
# Date: June 30 2014
############################################

rm(list=ls())
set.seed(1)

# set working directory
setwd("~/Dropbox/Violence exposure/Analysis/Replication")

# Prepare Variables and Create Subsetted Dataset
source("code/1.prepare.R")

# Implement Main Analyses
source("code/2.main_analysis.R")

# Heterogenous Treatment Effects (2nd intifada)
source("code/3.heterogeneousTEs.R")

# Robustness: Matching (2nd intifada)
source("code/4.matching.R")

# Robustness: narrow estimation window (2nd intifada)
source("code/5.narrow_window.R")

# Robustness: alternative treatment measure (2nd intifada)
source("code/6.alternativeDV.R")

# Robustness: violence exposure instead of combat experience (2nd intifada)
source("code/7.violence_exposure.R")

# Balance tests and descriptive stats
source("code/8.balance_test.R")

