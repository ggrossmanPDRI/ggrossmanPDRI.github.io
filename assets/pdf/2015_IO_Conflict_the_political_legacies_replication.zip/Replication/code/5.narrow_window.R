### combatants: changing window around eligibility cutoff
### compare health profiles 3 and 4 against health profiles 5, and 6.
### Table 10 (online appendix)

library(foreign)
library(stargazer)
library(AER)

rm(list=ls())
combatants <- read.dta("data/cleandata_combatants.dta")
exposure.high=combatants[combatants$intifada==1,]

exposure.high$HHleft <- as.numeric(exposure.high$HHideology > median(exposure.high$HHideology, na.rm=TRUE))
table(exposure.high$HHleft[exposure.high$sample3456==1])

dvs <- c("zleftA", "votechoice13", "zparticipationA", "zQ26_1", "peereffect1", "zprejudiceA", "zQ32_1", "zQ32_2", "zQ32_3")

# empty vectors to store results
coefs_all <- ses_all <- pval_all <-coefs_left <- ses_left <- pval_left <- coefs_right <- ses_right <- pval_right <- rep(NA, length(dvs))
iv_fits_all <- iv_fits_right <- iv_fits_left <- vector(mode="list", length=length(dvs))

### Estimate IVs for all DVs, among both high and low for 2nd Intifada period
for (i in 1:length(dvs)){
  iv_formula <- formula(paste0(dvs[i], "~ combat | z"))
  iv_fits_all[[i]] <- iv_fit_all <- ivreg(formula=iv_formula, data=subset(exposure.high, sample3456==1))  
  iv_fits_left[[i]] <- iv_fit_left <- ivreg(formula=iv_formula, data=subset(exposure.high, HHleft==1 & sample3456==1))
  iv_fits_right[[i]] <- iv_fit_right <- ivreg(formula=iv_formula, data=subset(exposure.high, HHleft==0 & sample3456==1))
  coefs_all[i] <- round(summary(iv_fit_all)$coefficients[2,1],5)  
  ses_all[i] <- round(summary(iv_fit_all)$coefficients[2,2],5)  
  pval_all[i] <- round(summary(iv_fit_all)$coefficients[2,4],5)  
  coefs_left[i] <- round(summary(iv_fit_left)$coefficients[2,1],5)
  ses_left[i] <- round(summary(iv_fit_left)$coefficients[2,2],5)
  pval_left[i] <- round(summary(iv_fit_left)$coefficients[2,4],5)
  coefs_right[i] <- round(summary(iv_fit_right)$coefficients[2,1],5)
  ses_right[i] <- round(summary(iv_fit_right)$coefficients[2,2],5)
  pval_right[i] <- round(summary(iv_fit_right)$coefficients[2,4],5)
}

## Make Table
dvs
idnum <- 1:9
outcomes <- as.numeric(idnum %in% 1:3) 
mechanisms <- as.numeric(idnum %in% 2:9) 

labels <- c("Reconciliation\nSummary index",
            "Vote choice: \n(2013 elections)", 
            "Political Participation \nsummary index",
            "Framing: support \nmilitary solutions", 
            "Peer effect: \nright-leaning unit",
            "Prejudice summary index", 
            "Terror attack","Missiles attack", "Existential threat"
)

labels2 <- c("Reconciliation summary index",
             "Vote choice: (2013 elections)", 
             "Political participation index",
             "Framing: support military solutions", 
             "Peer effect: right-leaning unit",
             "Prejudice summary index",
             "Terror attack","Missiles attack", "Existential threat"
)

group <- factor(idnum,levels=rev(seq(1:9)),labels=labels[9:1])
allmodels_all <- data.frame(group, coefs_all, ses_all, pval_all, idnum, outcomes, mechanisms)
allmodels_left <- data.frame(group, coefs_left, ses_left, pval_left, idnum, outcomes, mechanisms)
allmodels_right <- data.frame(group, coefs_right, ses_right, pval_right, idnum, outcomes, mechanisms)

allmodels_all <- within(allmodels_all, {pe <- coefs_all
                                          lb <- coefs_all + 1.645*ses_all
                                          ub <- coefs_all - 1.645*ses_all})
allmodels_left <- within(allmodels_left, {pe <- coefs_left
                                          lb <- coefs_left + 1.645*ses_left
                                          ub <- coefs_left - 1.645*ses_left})
allmodels_right <- within(allmodels_right, {pe <- coefs_right
                                            lb <- coefs_right + 1.645*ses_right
                                            ub <- coefs_right - 1.645*ses_right})

allests <- cbind(round(coefs_all,3), paste0("(",round(ses_all,3),")"), round(pval_all,3),
                 round(coefs_left,3), paste0("(",round(ses_left,3),")"), round(pval_left,3), 
                 round(coefs_right,3),paste0("(",round(ses_right,3),")"), round(pval_right,3))
rownames(allests) <- labels2
colnames(allests) <- c("Est", "SEs","Pval",  "Est", "SEs", "Pval", "Est", "SEs", "Pval")
print(xtable(allests, digits=3))


####################################################
# power Analysis (Fig 8 - online appendix)
####################################################
ITT_345678 <- lm(zleftA ~ z, data=subset(combatants, intifada==1 & sample345678==1))$coefficients[2]

### Suppose (reduced form) true treatment effect is -0.13
y.obs <- with(subset(combatants ,  intifada==1 & sample3456==1), zleftA)
z.obs <- with(subset(combatants ,  intifada==1 & sample3456==1), z)
d.obs <- with(subset(combatants ,  intifada==1 & sample3456==1), combat)

itt_d <- lm(d.obs ~ z.obs)   ### Observed compliance is 0.245, but what we really care about is the ITT

y1 <- y.obs*z.obs + (y.obs + ITT_345678)*(1-z.obs)
y0 <- y.obs*(1-z.obs) + (y.obs - ITT_345678)*(z.obs)
sims <- 1000

N_guess <- seq(from=374, to=2000, by=20)
lowers <-rep(NA, length(N_guess))
uppers <-rep(NA, length(N_guess))

for (i in 1:length(N_guess)){
  Z.block <- replicate(sims, rbinom(n=N_guess[i], size=1, prob=.5))
  ests <- rep(NA, sims)
  for (j in 1:sims){
    y1.grow <- sample(y1, size=N_guess[i], replace=TRUE)
    y0.grow <- sample(y0, size=N_guess[i], replace=TRUE)
    ests[j] <- mean(y1.grow[Z.block[,j] ==1]) -  mean(y0.grow[Z.block[,j] ==0])
  }
  lowers[i] <- quantile(ests, probs = c(.025))
  uppers[i] <- quantile(ests, probs = c(.975))
  print(i)
}

pdf("figures/PowerAnalysisITT.pdf")
plot(NA, xlim=c(350,2000), ylim=c(-.5, .3), 
     main="Power analysis: 95% CIs with hypothesized Effect: -0.12", 
     ylab="95% CI of estimated ITT",
     xlab="Additional subjects needed (4's and 5's)",
     xaxt="n")
axis(side=1, at= seq(from=300, to=2000, by=200), labels=seq(from=300, to=2000, by=200)-300)
arrows(x0=N_guess, x1=N_guess, y0=lowers, y1=uppers, angle=90, code=3, length=.1)
abline(h=0, lty=2, col="red", lwd=2)
abline(h=ITT_345678, lty=2, col="blue", lwd=2)
legend("bottomright", legend= c("Hypothetical True Effect: -0.12"),lty=2, col="blue", lwd=2)
dev.off()




