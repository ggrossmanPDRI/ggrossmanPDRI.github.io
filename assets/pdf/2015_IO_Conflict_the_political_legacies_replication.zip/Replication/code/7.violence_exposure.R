### Robustness check: violence exposure   
### use violence exposure instead of combat experience

library(foreign)
library(AER)
library(MatchIt)
library(stargazer)
library(ggplot2)
library(plyr)
library(grid)
library(gplots)
library(xtable)

combatants <- read.dta("data/cleandata_combatants.dta")
head(combatants)

# subset to 2nd Intifada period (2000-2006) and calulate HHideology indicator var
combatants=combatants[combatants$intifada==1,]
combatants$HHleft <- as.numeric(combatants$HHideology > median(combatants$HHideology, na.rm=TRUE))
table(combatants$HHleft)

# define alternative independenet variables
ivs <- c("combat", "combat2", "Q52_56_1", "Q52_56_2", "Q52_56_3", "Q52_56_4")

coefs_all <- ses_all <- pval_all <- coefs_left <- ses_left <- pval_left <- coefs_right <- ses_right <- pval_right <- rep(NA, length(ivs))
iv_fits_all <- iv_fits_right <- iv_fits_left <- vector(mode="list", length=length(ivs))

### Estimate IVs for all DVs, among both high and low
for (i in 1:length(ivs)){
  iv_formula <- formula(paste0("zleftA~", ivs[i], "| z"))
  iv_fits_all[[i]] <- iv_fit_all <- ivreg(formula=iv_formula, data=subset(combatants, sample345678==1))
  iv_fits_left[[i]] <- iv_fit_left <- ivreg(formula=iv_formula, data=subset(combatants, HHleft==1 & sample345678==1))
  iv_fits_right[[i]] <- iv_fit_right <- ivreg(formula=iv_formula, data=subset(combatants, HHleft==0 & sample345678==1))
  coefs_left[i] <- round(summary(iv_fit_left)$coefficients[2,1],5)
  coefs_all[i] <- round(summary(iv_fit_all)$coefficients[2,1],5)
  ses_all[i] <- round(summary(iv_fit_all)$coefficients[2,2],5)
  pval_all[i] <- round(summary(iv_fit_all)$coefficients[2,4],5)
  coefs_left[i] <- round(summary(iv_fit_left)$coefficients[2,1],5)
  ses_left[i] <- round(summary(iv_fit_left)$coefficients[2,2],5)
  pval_left[i] <- round(summary(iv_fit_left)$coefficients[2,4],5)
  coefs_right[i] <- round(summary(iv_fit_right)$coefficients[2,1],5)
  ses_right[i] <- round(summary(iv_fit_right)$coefficients[2,2],5)
  pval_right[i] <- round(summary(iv_fit_right)$coefficients[2,4],5)
}

###################################
###################################
## Table 11 (online appendix)
###################################
###################################
idnum <- 1:6
combat <- as.numeric(idnum %in% 1:2) 
violence <- as.numeric(idnum %in% 3:6)

labels <- c("Combat unit", "Operations participation", "Violence: IDF soldiers", "Violence: Israeli citizen", "Violence: enemy soldier", "Violence: Palestinian civilian")
group <- factor(idnum,levels=rev(seq(1:6)),labels=labels[6:1])

allmodels_all <- data.frame(group, coefs_all, ses_all, pval_all, idnum, combat, violence)
allmodels_left <- data.frame(group, coefs_left, ses_left, pval_left, idnum, combat, violence)
allmodels_right <- data.frame(group, coefs_right, ses_right, pval_right, idnum, combat, violence)


allmodels_all <- within(allmodels_all, {pe <- coefs_all
                                        lb <- coefs_all + 1.645*ses_all
                                        ub <- coefs_all - 1.645*ses_all})
allmodels_left <- within(allmodels_left, {pe <- coefs_left
                                          lb <- coefs_left + 1.645*ses_left
                                          ub <- coefs_left - 1.645*ses_left})
allmodels_right <- within(allmodels_right, {pe <- coefs_right
                                        lb <- coefs_right + 1.645*ses_right
                                        ub <- coefs_right - 1.645*ses_right})

allests <- cbind(round(coefs_all,3), paste0("(",round(ses_all,3),")"), round(pval_all,3),
                 round(coefs_left,3), paste0("(",round(ses_left,3),")"), round(pval_left,3), 
                 round(coefs_right,3), paste0("(",round(ses_right,3),")"), round(pval_right,3))

rownames(allests) <- labels
colnames(allests) <- c("Est", "SEs","Pval", "Est", "SEs","Pval",  "Est", "SEs", "Pval")
print(xtable(allests, digits=3))

###################################
###################################
# figure 4 (manuscript)
###################################
###################################

dvs <- c("zleftA", "votechoice13", "zparticipationA")
coefs_all_m1 <- ses_all_m1 <- pval_all_m1 <- coefs_left_m1 <- ses_left_m1 <- pval_left_m1 <- coefs_right_m1 <- ses_right_m1 <- pval_right_m1 <- rep(NA, length(dvs))
coefs_all_m2 <- ses_all_m2 <- pval_all_m2 <- coefs_left_m2 <- ses_left_m2 <- pval_left_m2 <- coefs_right_m2 <- ses_right_m2 <- pval_right_m2 <- rep(NA, length(dvs))
coefs_all_m3 <- ses_all_m3 <- pval_all_m3 <- coefs_left_m3 <- ses_left_m3 <- pval_left_m3 <- coefs_right_m3 <- ses_right_m3 <- pval_right_m3 <- rep(NA, length(dvs))
coefs_all_m4 <- ses_all_m4 <- pval_all_m4 <- coefs_left_m4 <- ses_left_m4 <- pval_left_m4 <- coefs_right_m4 <- ses_right_m4 <- pval_right_m4 <- rep(NA, length(dvs))
coefs_all_m5 <- ses_all_m5 <- pval_all_m5 <- coefs_left_m5 <- ses_left_m5 <- pval_left_m5 <- coefs_right_m5 <- ses_right_m5 <- pval_right_m5 <- rep(NA, length(dvs))
coefs_all_m6 <- ses_all_m6 <- pval_all_m6 <- coefs_left_m6 <- ses_left_m6 <- pval_left_m6 <- coefs_right_m6 <- ses_right_m6 <- pval_right_m6 <- rep(NA, length(dvs))

iv_fits_all <- iv_fits_right <- iv_fits_left <- vector(mode="list", length=length(dvs))

### Estimate IVs for all DVs, among both left and right
for (i in 1:length(dvs)){
  iv_formula <- formula(paste0(dvs[i], "~ Q52_56_1 | z"))
  iv_fits_all[[i]] <- iv_fit_all <- ivreg(formula=iv_formula, data=subset(combatants, sample345678==1))  
  iv_fits_left[[i]] <- iv_fit_left <- ivreg(formula=iv_formula, data=subset(combatants, HHleft==1 & sample345678==1))
  iv_fits_right[[i]] <- iv_fit_right <- ivreg(formula=iv_formula, data=subset(combatants, HHleft==0 & sample345678==1))
  coefs_all_m1[i] <- round(summary(iv_fit_all)$coefficients[2,1],5)
  ses_all_m1[i] <- round(summary(iv_fit_all)$coefficients[2,2],5)
  pval_all_m1[i] <- round(summary(iv_fit_all)$coefficients[2,4],5)
  coefs_left_m1[i] <- round(summary(iv_fit_left)$coefficients[2,1],5)
  ses_left_m1[i] <- round(summary(iv_fit_left)$coefficients[2,2],5)
  pval_left_m1[i] <- round(summary(iv_fit_left)$coefficients[2,4],5)
  coefs_right_m1[i] <- round(summary(iv_fit_right)$coefficients[2,1],5)
  ses_right_m1[i] <- round(summary(iv_fit_right)$coefficients[2,2],5)
  pval_right_m1[i] <- round(summary(iv_fit_right)$coefficients[2,4],5)
}

for (i in 1:length(dvs)){
  iv_formula <- formula(paste0(dvs[i], "~ Q52_56_2 | z"))
  iv_fits_all[[i]] <- iv_fit_all <- ivreg(formula=iv_formula, data=subset(combatants, sample345678==1))  
  iv_fits_left[[i]] <- iv_fit_left <- ivreg(formula=iv_formula, data=subset(combatants, HHleft==1 & sample345678==1))
  iv_fits_right[[i]] <- iv_fit_right <- ivreg(formula=iv_formula, data=subset(combatants, HHleft==0 & sample345678==1))
  coefs_all_m2[i] <- round(summary(iv_fit_all)$coefficients[2,1],5)
  ses_all_m2[i] <- round(summary(iv_fit_all)$coefficients[2,2],5)
  pval_all_m2[i] <- round(summary(iv_fit_all)$coefficients[2,4],5)
  coefs_left_m2[i] <- round(summary(iv_fit_left)$coefficients[2,1],5)
  ses_left_m2[i] <- round(summary(iv_fit_left)$coefficients[2,2],5)
  pval_left_m2[i] <- round(summary(iv_fit_left)$coefficients[2,4],5)
  coefs_right_m2[i] <- round(summary(iv_fit_right)$coefficients[2,1],5)
  ses_right_m2[i] <- round(summary(iv_fit_right)$coefficients[2,2],5)
  pval_right_m2[i] <- round(summary(iv_fit_right)$coefficients[2,4],5)
}

for (i in 1:length(dvs)){
  iv_formula <- formula(paste0(dvs[i], "~ Q52_56_3 | z"))
  iv_fits_all[[i]] <- iv_fit_all <- ivreg(formula=iv_formula, data=subset(combatants, sample345678==1))  
  iv_fits_left[[i]] <- iv_fit_left <- ivreg(formula=iv_formula, data=subset(combatants, HHleft==1 & sample345678==1))
  iv_fits_right[[i]] <- iv_fit_right <- ivreg(formula=iv_formula, data=subset(combatants, HHleft==0 & sample345678==1))
  coefs_all_m3[i] <- round(summary(iv_fit_all)$coefficients[2,1],5)
  ses_all_m3[i] <- round(summary(iv_fit_all)$coefficients[2,2],5)
  pval_all_m3[i] <- round(summary(iv_fit_all)$coefficients[2,4],5)
  coefs_left_m3[i] <- round(summary(iv_fit_left)$coefficients[2,1],5)
  ses_left_m3[i] <- round(summary(iv_fit_left)$coefficients[2,2],5)
  pval_left_m3[i] <- round(summary(iv_fit_left)$coefficients[2,4],5)
  coefs_right_m3[i] <- round(summary(iv_fit_right)$coefficients[2,1],5)
  ses_right_m3[i] <- round(summary(iv_fit_right)$coefficients[2,2],5)
  pval_right_m3[i] <- round(summary(iv_fit_right)$coefficients[2,4],5)
}

for (i in 1:length(dvs)){
  iv_formula <- formula(paste0(dvs[i], "~ Q52_56_4 | z"))
  iv_fits_all[[i]] <- iv_fit_all <- ivreg(formula=iv_formula, data=subset(combatants, sample345678==1))  
  iv_fits_left[[i]] <- iv_fit_left <- ivreg(formula=iv_formula, data=subset(combatants, HHleft==1 & sample345678==1))
  iv_fits_right[[i]] <- iv_fit_right <- ivreg(formula=iv_formula, data=subset(combatants, HHleft==0 & sample345678==1))
  coefs_all_m4[i] <- round(summary(iv_fit_all)$coefficients[2,1],5)
  ses_all_m4[i] <- round(summary(iv_fit_all)$coefficients[2,2],5)
  pval_all_m4[i] <- round(summary(iv_fit_all)$coefficients[2,4],5)
  coefs_left_m4[i] <- round(summary(iv_fit_left)$coefficients[2,1],5)
  ses_left_m4[i] <- round(summary(iv_fit_left)$coefficients[2,2],5)
  pval_left_m4[i] <- round(summary(iv_fit_left)$coefficients[2,4],5)
  coefs_right_m4[i] <- round(summary(iv_fit_right)$coefficients[2,1],5)
  ses_right_m4[i] <- round(summary(iv_fit_right)$coefficients[2,2],5)
  pval_right_m4[i] <- round(summary(iv_fit_right)$coefficients[2,4],5)
}


pdf(file="figures/ViolenceWitness.pdf", width=14, height=10)
	deg=3
	par(mfrow=c(1,3))
plot(NA, ylim=c(-5, 2), xlim=c(0,3), main="IDF Soldier", ylab="LATE", xlab="", xaxt="n")
axis(side=1, at=.5:2.5, labels=c("Reconciliation","Voting", "Participation"))
plotCI(.5:2.5, coefs_all_m1, 
       ui=coefs_all_m1 + 1.645*ses_all_m1,
       li=coefs_all_m1 - 1.645*ses_all_m1, lwd=3,
       add=TRUE)
abline(h=0, lty=2, col="red")
plot(NA, ylim=c(-5, 2), xlim=c(0,3), main="Armed Palestinian", ylab="LATE", xlab="", xaxt="n")
axis(side=1, at=.5:2.5, labels=c("Reconciliation","Voting", "Participation"))
plotCI(.5:2.5, coefs_all_m3, 
       ui=coefs_all_m3 + 1.645*ses_all_m3,
       li=coefs_all_m3 - 1.645*ses_all_m3,  lwd=3,
       add=TRUE)
abline(h=0, lty=2, col="red")
plot(NA, ylim=c(-5, 2), xlim=c(0,3), main="Palestinian Civilian", ylab="LATE", xlab="", xaxt="n")
axis(side=1, at=.5:2.5, labels=c("Reconciliation","Voting", "Participation"))
plotCI(.5:2.5, coefs_all_m4, 
       ui=coefs_all_m4 + 1.645*ses_all_m4,
       li=coefs_all_m4 - 1.645*ses_all_m4,  lwd=3,
       add=TRUE)
abline(h=0, lty=2, col="red")
dev.off()

