### combatants: Heterogeneous Effects

library(foreign)
library(AER)
library(stargazer)
library(xtable)
library(SDMTools)
library(arm)
library(gplots)

combatants <- read.dta("data/cleandata_combatants.dta")
names(combatants)

##############################################################
## Table 5 (online appendix): pool two surveys 
##############################################################
combatants <- read.dta("data/cleandata_combatants.dta")
combatants$HHleft <- as.numeric(combatants$HHideology > median(combatants$HHideology, na.rm=TRUE))
table(combatants$HHleft)

# weight each sample in the pooled data by sample size 
combatants$strataw[combatants$intifada==0] = 1
combatants$strataw[combatants$intifada==1] = length(combatants$intifada[combatants$intifada==1])/length(combatants$intifada[combatants$intifada==0])

# Define Dependent Variables 
#1:11 -- Attitudes
#12:13 -- vote
#14:23 -- Participation
#24:25 -- Socialization
#26:31 -- Prejudice
#31:32 -- Threat

dvs <- c("zleftA", "zQ16b", "zQ17b", "zQ18b", "zQ21b", "zQ23b", "zQ24b", "zQ28b", "zQ29b", "zQ30b", "zQ33",
         "votechoice13", "firstvote",
         "zparticipationA", "zQ35b", "zQ36b", "zQ37_1", "zQ37_2", "zQ37_3", "zQ37_4", "zQ37_5", "zQ37_6", "zQ37_7",
         "zQ26_1", "peereffect1", 
         "zprejudiceA", "zintelligent", "ztrustworthy", "znonegoistic", "znonviolent","zQ22b",
         "zQ32_1","zQ32_2","zQ32_3"
)

# empty vectors to store results
coefs_all <- ses_all <- pval_all <- coefs_left <- ses_left <- pval_left <- coefs_right <- ses_right <- pval_right <- rep(NA, length(dvs))
iv_fits_all <- iv_fits_right <- iv_fits_left <- vector(mode="list", length=length(dvs))

### Estimate IVs for all DVs, among both left and right
for (i in 1:length(dvs)){
  iv_formula <- formula(paste0(dvs[i], "~ combat | z"))
  iv_fits_all[[i]] <- iv_fit_all <- ivreg(formula=iv_formula, data=subset(combatants, sample345678==1), weights=strataw)  
  iv_fits_left[[i]] <- iv_fit_left <- ivreg(formula=iv_formula, data=subset(combatants, HHleft==1 & sample345678==1), weights=strataw)
  iv_fits_right[[i]] <- iv_fit_right <- ivreg(formula=iv_formula, data=subset(combatants, HHleft==0 & sample345678==1), weights=strataw)
  coefs_all[i] <- round(summary(iv_fit_all)$coefficients[2,1],5)
  ses_all[i] <- round(summary(iv_fit_all)$coefficients[2,2],5)
  pval_all[i] <- round(summary(iv_fit_all)$coefficients[2,4],5)
  coefs_left[i] <- round(summary(iv_fit_left)$coefficients[2,1],5)
  ses_left[i] <- round(summary(iv_fit_left)$coefficients[2,2],5)
  pval_left[i] <- round(summary(iv_fit_left)$coefficients[2,4],5)
  coefs_right[i] <- round(summary(iv_fit_right)$coefficients[2,1],5)
  ses_right[i] <- round(summary(iv_fit_right)$coefficients[2,2],5)
  pval_right[i] <- round(summary(iv_fit_right)$coefficients[2,4],5)
}


## Make Table 5 (online appendix)
dvs
idnum <- 1:34
attitudes <- as.numeric(idnum %in% 1:11) 
vote <- as.numeric(idnum %in% 12:13)
participation <- as.numeric(idnum %in% 14:23)
socialization <- as.numeric(idnum %in% 24:25)
prejudice <- as.numeric(idnum %in% 26:31)
threat <- as.numeric(idnum %in% 32:34)

labels <- c("Reconciliation\nsummary index","Support negotiated \nterritorial withdrawal", "Support negotiated \ndivision of Jerusalem","Support negotiated \nrefugee right of return", "Palestinians are \npartners for peace", 
            "Support conciliatory solutions\n(e.g., two states)", 
            "Israel indivisible","Settlements endanger\n Israeli democracy", "Occupation is \nimmoral / illegal", "Oppose limitations on \nhuman right NGOs","Right-Left scale \nself-placement",
            "Vote choice: \n(2013 elections)", "Vote choice: \n(first election)",
            "Political participation \ index","Political interest","Party membership","Demonstration","Petition","Advocacy group","Contact public official","Radio call","Newspaper comment","Facebook political status",
            "Framing: support \nmilitary solutions", "Peer effect: \nright-leaning unit",
            "Prejudice summary index","Intelligence\n(difference)","Trustworthiness\n(difference)","Altruism\n(difference)","Non-violence\n(difference)", "Palestinians' goal:\nExpel Jews",
            "Terror attack","Missiles attack", "Existential threat"
)
labels2 <- c("Reconciliation summary index","Support negotiated territorial withdrawal", 
             "Support negotiated division of Jerusalem", "Support negotiated refugee right of return", "Palestinians are partners for peace", 
             "Support conciliatory solutions (two states)", "Israel indivisible","Settlements endanger Israeli democracy", "Occupation is immoral / illegal", "Oppose limitations on human right NGOs","Right-Left scale self-placement",
             "Vote choice: (2013 elections)", "Vote choice: (first election)",
             "Political participation index","Political interest","Party membership","Demonstration","Petition","Advocacy group","Contact public official","Radio call","Newspaper comment","Facebook political status",
             "Framing: support military solutions", "Peer effect: right-leaning unit",
             "Prejudice summary index","Intelligence (difference)","Trustworthiness (difference)","Altruism (difference)","Non-violence (difference)", "Palestinians' goal:Expel Jews",
             "Terror attack","Missiles attack", "Existential threat"
)

group <- factor(idnum,levels=rev(seq(1:34)),labels=labels[34:1])
allmodels_all <- data.frame(group, coefs_all, ses_all, pval_all, idnum, attitudes, vote, participation, socialization, prejudice, threat)
allmodels_left <- data.frame(group, coefs_left, ses_left, pval_left, idnum, attitudes, vote, participation, socialization, prejudice, threat)
allmodels_right <- data.frame(group, coefs_right, ses_right, pval_right, idnum, attitudes, vote, participation, socialization, prejudice, threat)

allmodels_all <- within(allmodels_all, {pe <- coefs_all
                                        lb <- coefs_all + 1.645*ses_all
                                        ub <- coefs_all - 1.645*ses_all})
allmodels_left <- within(allmodels_left, {pe <- coefs_left
                                          lb <- coefs_left + 1.645*ses_left
                                          ub <- coefs_left - 1.645*ses_left})
allmodels_right <- within(allmodels_right, {pe <- coefs_right
                                        lb <- coefs_right + 1.645*ses_right
                                        ub <- coefs_right - 1.645*ses_right})

allests <- cbind(round(coefs_all,3), paste0("(",round(ses_all,3),")"), round(pval_all,3),
                 round(coefs_left,3), paste0("(",round(ses_left,3),")"), round(pval_left,3), 
                 round(coefs_right,3), paste0("(",round(ses_right,3),")"), round(pval_right,3))
rownames(allests) <- labels2
colnames(allests) <- c("Est", "SEs","Pval", "Est", "SEs","Pval",  "Est", "SEs", "Pval")
print(xtable(allests, digits=3))


##############################################################
## Table 7 (online appendix): cut at median 
##############################################################
# subset to 2nd Intifada period (2000-2006)
exposure.high=combatants[combatants$intifada==1,]
exposure.high$HHleft <- as.numeric(exposure.high$HHideology > median(exposure.high$HHideology, na.rm=TRUE))
table(exposure.high$HHleft)

# subset to post-Gaza withdrawal period (2007-2012)
exposure.low=combatants[combatants$intifada==0,]
exposure.low$HHleft <- as.numeric(exposure.low$HHideology >= median(exposure.low$HHideology, na.rm=TRUE))
table(exposure.low$HHleft)

dvs <- c("zleftA", "votechoice13", "zparticipationA", "zQ26_1", "peereffect1", "zprejudiceA", "zQ32_1", "zQ32_2", "zQ32_3")

# empty vectors to store results
coefs_left <- ses_left <- pval_left <- coefs_right <- ses_right <- pval_right <- coefs_diff <- rep(NA, length(dvs))
iv_fits_right <- iv_fits_left <- vector(mode="list", length=length(dvs))

### Estimate IVs for all DVs, among both high and low for 2nd Intifada period
for (i in 1:length(dvs)){
  iv_formula <- formula(paste0(dvs[i], "~ combat | z"))
  iv_fits_left[[i]] <- iv_fit_left <- ivreg(formula=iv_formula, data=subset(exposure.high, HHleft==1 & sample345678==1))
  iv_fits_right[[i]] <- iv_fit_right <- ivreg(formula=iv_formula, data=subset(exposure.high, HHleft==0 & sample345678==1))
  coefs_left[i] <- round(summary(iv_fit_left)$coefficients[2,1],5)
  ses_left[i] <- round(summary(iv_fit_left)$coefficients[2,2],5)
  pval_left[i] <- round(summary(iv_fit_left)$coefficients[2,4],5)
  coefs_right[i] <- round(summary(iv_fit_right)$coefficients[2,1],5)
  ses_right[i] <- round(summary(iv_fit_right)$coefficients[2,2],5)
  pval_right[i] <- round(summary(iv_fit_right)$coefficients[2,4],5)
  coefs_diff[i] <- round(summary(iv_fit_left)$coefficients[2,1]-summary(iv_fit_right)$coefficients[2,1], 5)
}

dvs
idnum <- 1:9
outcomes <- as.numeric(idnum %in% 1:3) 
mechanisms <- as.numeric(idnum %in% 2:9) 

labels <- c("Reconciliation\nSummary index",
            "Vote choice: \n(2013 elections)", 
            "Political participation \nsummary index",
            "Framing: support \nmilitary solutions", 
            "Peer effect: \nright-leaning unit",
            "Prejudice summary index", 
            "Terror attack","Missiles attack", "Existential threat"
)

labels2 <- c("Reconciliation summary index",
             "Vote choice: (2013 elections)", 
             "Political participation index",
             "Framing: support military solutions", 
             "Peer effect: right-leaning unit",
             "Prejudice summary index",
             "Terror attack","Missiles attack", "Existential threat"
)

group <- factor(idnum,levels=rev(seq(1:9)),labels=labels[9:1])
allmodels_left <- data.frame(group, coefs_left, ses_left, pval_left, idnum, outcomes, mechanisms)
allmodels_right <- data.frame(group, coefs_right, ses_right, pval_right, idnum, outcomes, mechanisms)
allmodels_left <- within(allmodels_left, {pe <- coefs_left
                                          lb <- coefs_left + 1.645*ses_left
                                          ub <- coefs_left - 1.645*ses_left})
allmodels_right <- within(allmodels_right, {pe <- coefs_right
                                        lb <- coefs_right + 1.645*ses_right
                                        ub <- coefs_right - 1.645*ses_right})

allmodels_diff <- data.frame(group, coefs_diff)

allests <- cbind(round(coefs_left,3), paste0("(",round(ses_left,3),")"), round(pval_left,3), round(coefs_right,3), paste0("(",round(ses_right,3),")"), round(pval_right,3), round(coefs_diff,3))
rownames(allests) <- labels2
colnames(allests) <- c("Est", "SEs","Pval",  "Est", "SEs", "Pval", "Diff")
print(xtable(allests, digits=3))

##############################################################
## Table 8 (online appendix): cut below median 
##############################################################

# subset to 2nd Intifada period (2000-2006)
exposure.high=combatants[combatants$intifada==1,]
exposure.high$HHleft <- as.numeric(exposure.high$HHideology >=3, na.rm=TRUE)
table(exposure.high$HHleft)

dvs <- c("zleftA", "votechoice13", "zparticipationA", "zQ26_1", "peereffect1", "zprejudiceA", "zQ32_1", "zQ32_2", "zQ32_3")

# empty vectors to store results
coefs_left <- ses_left <- pval_left <- coefs_right <- ses_right <- pval_right <- coefs_diff <- rep(NA, length(dvs))
iv_fits_right <- iv_fits_left <- vector(mode="list", length=length(dvs))

### Estimate IVs for all DVs, among both high and low for 2nd Intifada period
for (i in 1:length(dvs)){
  iv_formula <- formula(paste0(dvs[i], "~ combat | z"))
  iv_fits_left[[i]] <- iv_fit_left <- ivreg(formula=iv_formula, data=subset(exposure.high, HHleft==1 & sample345678==1))
  iv_fits_right[[i]] <- iv_fit_right <- ivreg(formula=iv_formula, data=subset(exposure.high, HHleft==0 & sample345678==1))
  coefs_left[i] <- round(summary(iv_fit_left)$coefficients[2,1],5)
  ses_left[i] <- round(summary(iv_fit_left)$coefficients[2,2],5)
  pval_left[i] <- round(summary(iv_fit_left)$coefficients[2,4],5)
  coefs_right[i] <- round(summary(iv_fit_right)$coefficients[2,1],5)
  ses_right[i] <- round(summary(iv_fit_right)$coefficients[2,2],5)
  pval_right[i] <- round(summary(iv_fit_right)$coefficients[2,4],5)
  coefs_diff[i] <- round(summary(iv_fit_left)$coefficients[2,1]-summary(iv_fit_right)$coefficients[2,1], 5)
}


dvs
idnum <- 1:9
outcomes <- as.numeric(idnum %in% 1:3) 
mechanisms <- as.numeric(idnum %in% 2:9) 

labels <- c("Reconciliation\nSummary index",
            "Vote choice: \n(2013 elections)", 
            "Political participation \nsummary index",
            "Framing: support \nmilitary solutions", 
            "Peer effect: \nright-leaning unit",
            "Prejudice summary index", 
            "Terror attack","Missiles attack", "Existential threat"
)

labels2 <- c("Reconciliation summary index",
             "Vote choice: (2013 elections)", 
             "Political participation index",
             "Framing: support military solutions", 
             "Peer effect: right-leaning unit",
             "Prejudice summary index",
             "Terror attack","Missiles attack", "Existential threat"
)

group <- factor(idnum,levels=rev(seq(1:9)),labels=labels[9:1])
allmodels_left <- data.frame(group, coefs_left, ses_left, pval_left, idnum, outcomes, mechanisms)
allmodels_right <- data.frame(group, coefs_right, ses_right, pval_right, idnum, outcomes, mechanisms)
allmodels_left <- within(allmodels_left, {pe <- coefs_left
                                          lb <- coefs_left + 1.645*ses_left
                                          ub <- coefs_left - 1.645*ses_left})
allmodels_right <- within(allmodels_right, {pe <- coefs_right
                                        lb <- coefs_right + 1.645*ses_right
                                        ub <- coefs_right - 1.645*ses_right})

allmodels_diff <- data.frame(group, coefs_diff)

allests <- cbind(round(coefs_left,3), paste0("(",round(ses_left,3),")"), round(pval_left,3), round(coefs_right,3), paste0("(",round(ses_right,3),")"), round(pval_right,3), round(coefs_diff,3))
rownames(allests) <- labels2
colnames(allests) <- c("Est", "SEs","Pval",  "Est", "SEs", "Pval", "Diff")
print(xtable(allests, digits=3))


##############################################################
## Figure 5 (manuscript): heterogenous effects 
##############################################################
combatants <- read.dta("data/cleandata_combatants.dta")
head(combatants)

combatants=combatants[combatants$intifada==1,]
dim(combatants)

combatants$HHleft <- as.numeric(combatants$HHideology[combatants$intifada==1] > median(combatants$HHideology[combatants$intifada==1], na.rm=TRUE))
combatants$HHleftB <- as.numeric(combatants$HHideology[combatants$intifada==1] >=3, na.rm=TRUE)
table(combatants$HHleft)
table(combatants$HHleftB)

# Reconcilation
attitudes_high <- ivreg(zleftA ~ combat | z, data=combatants)
attitudes_highLeft <- ivreg(zleftA ~ combat | z, data=subset(combatants, HHleft==1))
attitudes_highRight <- ivreg(zleftA ~ combat | z, data=subset(combatants, HHleft==0 ))
attitudes_highLeftB <- ivreg(zleftA ~ combat | z, data=subset(combatants, HHleftB==1))
attitudes_highRightB <- ivreg(zleftA ~ combat | z, data=subset(combatants, HHleftB==0 ))

# Voting
voting_high <- ivreg(votechoice13 ~ combat | z, data=combatants)
voting_highLeft <- ivreg(votechoice13 ~ combat | z, data=subset(combatants, HHleft==1))
voting_highRight <- ivreg(votechoice13 ~ combat | z, data=subset(combatants, HHleft==0 ))
voting_highLeftB <- ivreg(votechoice13 ~ combat | z, data=subset(combatants, HHleftB==1))
voting_highRightB <- ivreg(votechoice13 ~ combat | z, data=subset(combatants, HHleftB==0 ))

# Participation
participation_high <- ivreg(zparticipationA ~ combat | z, data=combatants)
participation_highLeft <- ivreg(zparticipationA ~ combat | z, data=subset(combatants, HHleft==1))
participation_highRight <- ivreg(zparticipationA ~ combat | z, data=subset(combatants, HHleft==0 ))
participation_highLeftB <- ivreg(zparticipationA ~ combat | z, data=subset(combatants, HHleftB==1))
participation_highRightB <- ivreg(zparticipationA ~ combat | z, data=subset(combatants, HHleftB==0 ))

### Robustness to different kinds of matching: Matching on covariates
all_ests_high <-  c(summary(attitudes_high)$coefficients[2,1], summary(voting_high)$coefficients[2,1], summary(participation_high)$coefficients[2,1])
all_ests_highLeft <- c(summary(attitudes_highLeft)$coefficients[2,1], summary(voting_highLeft)$coefficients[2,1], summary(participation_highLeft)$coefficients[2,1])
all_ests_highRight <- c(summary(attitudes_highRight)$coefficients[2,1], summary(voting_highRight)$coefficients[2,1], summary(participation_highRight)$coefficients[2,1])
all_ests_highLeftB <- c(summary(attitudes_highLeftB)$coefficients[2,1], summary(voting_highLeftB)$coefficients[2,1], summary(participation_highLeftB)$coefficients[2,1])
all_ests_highRightB <- c(summary(attitudes_highRightB)$coefficients[2,1], summary(voting_highRightB)$coefficients[2,1], summary(participation_highRightB)$coefficients[2,1])

all_ses_high <-  c(summary(attitudes_high)$coefficients[2,2], summary(voting_high)$coefficients[2,2], summary(participation_high)$coefficients[2,2])
all_ses_highLeft <- c(summary(attitudes_highLeft)$coefficients[2,2], summary(voting_highLeft)$coefficients[2,2], summary(participation_highLeft)$coefficients[2,2])
all_ses_highRight <- c(summary(attitudes_highRight)$coefficients[2,2],summary(voting_highRight)$coefficients[2,2], summary(participation_highRight)$coefficients[2,2])
all_ses_highLeftB <- c(summary(attitudes_highLeftB)$coefficients[2,2], summary(voting_highLeftB)$coefficients[2,2], summary(participation_highLeftB)$coefficients[2,2])
all_ses_highRightB <- c(summary(attitudes_highRightB)$coefficients[2,2],summary(voting_highRightB)$coefficients[2,2], summary(participation_highRightB)$coefficients[2,2])


pdf(file="figures/HetroEffectsDiffCuts.pdf", width=12, height=10)
	deg=3
	par(mfrow=c(1,2))
plot(NA, ylim=c(-1.25, 1), xlim=c(0,3), main="Cut at Median", ylab="LATE of Combat Exposure", xlab="", xaxt="n")
axis(side=1, at=.5:2.5, labels=c("Reconciliation","Voting", "Participation"))
plotCI(.35:2.35, all_ests_highLeft, 
       ui=all_ests_highLeft + 1.645*all_ses_highLeft,
       li=all_ests_highLeft - 1.645*all_ses_highLeft,col="black", lwd=3, lty=1,
       add=TRUE)
plotCI(.65:2.65, all_ests_highRight, 
       ui=all_ests_highRight + 1.645*all_ses_highRight,
       li=all_ests_highRight - 1.645*all_ses_highRight, col="black", lwd=3, lty=5,
       add=TRUE)
abline(h=0, lty=2,  col="red")

plot(NA, ylim=c(-1.25, 1), xlim=c(0,3), main="Cut below Median", ylab="LATE of Combat Exposure", xlab="", xaxt="n")
axis(side=1, at=.5:2.5, labels=c("Reconciliation","Voting", "Participation"))
plotCI(.35:2.35, all_ests_highLeftB, 
       ui=all_ests_highLeftB + 1.645*all_ses_highLeftB,
       li=all_ests_highLeftB - 1.645*all_ses_highLeftB,col="black", lwd=3, lty=1,
       add=TRUE)
plotCI(.65:2.65, all_ests_highRightB, 
       ui=all_ests_highRightB + 1.645*all_ses_highRightB,
       li=all_ests_highRightB - 1.645*all_ses_highRightB, col="black", lwd=3, lty=5,
       add=TRUE)
abline(h=0, lty=2, col="red")
dev.off()


