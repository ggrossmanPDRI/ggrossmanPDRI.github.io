### combatants AEC robustness to alternative matches
### evaluated with respect to attitudes
### All estimates among "high intensity" period.

library(foreign)
library(AER)
library(MatchIt)
library(gplots)
library(ebal)
library(cem)
library(Matching)
library(SDMTools)
library(arm)
library(xtable)

combatants <- read.dta("data/cleandata_combatants.dta")
head(combatants)

combatants=combatants[combatants$intifada==1,]
dim(combatants)
class(combatants)

combatants$HHleft <- as.numeric(combatants$HHideology[combatants$intifada==1] > median(combatants$HHideology[combatants$intifada==1], na.rm=TRUE))
#combatants$HHleft <- as.numeric(combatants$HHideology[combatants$intifada==1] >=3, na.rm=TRUE)
table(combatants$HHleft)

# Define Formulae
covs <- "native +HHincome+HHideology+ Q47b + secular+ traditional+ religious+ sephardic+ ashkenazi+ mixed+ USSR+ area1+ area2+ area3+ area4+area5+area6"
z_on_cov_formula <- formula(paste0("z ~ ", covs))
combat_on_cov_formula <- formula(paste0("combat ~ ", covs))
first_stage_formula <- formula(paste0("combat ~ z+ ", covs))
iv_zleftA_cov_formula <- formula(paste0("zleftA ~ combat +", covs, "| z + ", covs ))

# No matching no covariates
attitudes_34v5678_high <- ivreg(zleftA ~ combat | z, data=combatants)
attitudes_34v5678_highLeft <- ivreg(zleftA ~ combat | z, data=subset(combatants, HHleft==1))
attitudes_34v5678_highRight <- ivreg(zleftA ~ combat | z, data=subset(combatants, HHleft==0 ))

############################################
# First stage
############################################

# No matching with covariates
# first-stage regression 
FirstStage= lm(combat~z, data=combatants)
summary(FirstStage)

ZOnCovs= lm(z_on_cov_formula, data=combatants)
summary(ZOnCovs)
pdf(file="figures/ZOnCovs.pdf", width=15, height=10)
coefplot(FirstStageCov,varnames=c("Intercept", "Native", "H-income", "H-ideology", "Father", "Secular", "Traditional", "Religious", 
                                  "Sephradic", "Ashkenazi", "Mixed race", "USSR", "Jerusalem", "North", "Haifa", "Center", "Tel-Aviv",  "South"),
         CI=2, xlim=c(-0.4,0.4))
dev.off()

############################################
# 1  calculate the propensity to serve as combatant 
# 2. create predicted probabilities
# 3. test distribution by z (combat eligibility)
############################################

probit.model <- glm(formula = combat_on_cov_formula, family = binomial(link = "probit"), data = subset(combatants, z==1))
combatants$highcombathat <- predict(probit.model, combatants, type = "response") 
by(combatants$highcombathat, combatants$z, function(x) c(N=length(x),mean=mean(x), median=median(x)))

############################################
## NN matching on "combat propensity"
############################################
set.seed(05282013)
mhigh.out1 <- matchit(z ~ highcombathat, data = combatants, method="nearest", replace = TRUE, discard="both")
mhigh.data1 <- match.data(mhigh.out1)

attitudes_34v5678_m1_high <- ivreg(zleftA ~ combat | z, weights=weights, data=mhigh.data1)
attitudes_34v5678_m1_highLeft <- ivreg(zleftA ~ combat | z, weights=weights, data=subset(mhigh.data1, HHleft==1))
attitudes_34v5678_m1_highRight <- ivreg(zleftA ~ combat | z, weights=weights, data=subset(mhigh.data1, HHleft==0))

############################################
### NN matche on covariates instead on the propensity to join combat unit
############################################
mhigh.out2 <- matchit(formula=z_on_cov_formula, data = combatants, method="nearest", replace = TRUE, discard="both")
summary(mhigh.out2)
mhigh.data2<- match.data(mhigh.out2)

attitudes_34v5678_m2_high <- ivreg(zleftA ~ combat | z, weights=weights, data=subset(mhigh.data2, intifada==1 & sample345678==1))
attitudes_34v5678_m2_highLeft <- ivreg(zleftA ~ combat | z, weights=weights, data=subset(mhigh.data2, HHleft==1 ))
attitudes_34v5678_m2_highRight <- ivreg(zleftA ~ combat | z, weights=weights, data=subset(mhigh.data2, HHleft==0 ))

############################################
# Coarsed Exact Matching
# CEM 1: match on combat propensity 
############################################

mhigh.out3 <- matchit(z ~ highcombathat, data = combatants, method="cem", discard="both")
summary(mhigh.out3) 
mhigh.data3 <- match.data(mhigh.out3)

attitudes_34v5678_m3_high <- ivreg(zleftA ~ combat | z, weights=weights, data=subset(mhigh.data3, intifada==1 & sample345678==1))
attitudes_34v5678_m3_highLeft <- ivreg(zleftA ~ combat | z, weights=weights, data=subset(mhigh.data3, HHleft==1))
attitudes_34v5678_m3_highRight <- ivreg(zleftA ~ combat | z, weights=weights, data=subset(mhigh.data3, HHleft==0))

############################################
# CEM 2: match on covariates 
# note HHincome and HHideology collpased into smaller number of units to reduce number of strata
############################################

mhigh.out4 <- matchit(z ~ age_factor+ native + HHincome_factor + HHideology_factor + secular + traditional + religious +haredi + sephardic + ashkenazi + mixed + USSR + Jerusalem+ North+ Center+ South, data = combatants, method="cem", discard="both")
summary(mhigh.out4) 
mhigh.data4 <- match.data(mhigh.out4)

attitudes_34v5678_m4_high <- ivreg(zleftA ~ combat | z, weights=weights, data=subset(mhigh.data4, intifada==1 & sample345678==1))
attitudes_34v5678_m4_highLeft <- ivreg(zleftA ~ combat | z, weights=weights, data=subset(mhigh.data4, HHleft==1))
attitudes_34v5678_m4_highRight <- ivreg(zleftA ~ combat | z, weights=weights, data=subset(mhigh.data4, HHleft==0))

############################################
# Entropy Balancing
# EB1: match on combat propensity
############################################
covs.names2 <- c("highcombathat", "HHideology")
mout2 <- MatchBalance(z ~ highcombathat+HHideology, combatants)
options(digits=2)
baltest.collect(matchbal.out=mout2, var.names=covs.names2,after=FALSE)

X2=combatants[covs.names2]
ebalout2 <- ebalance(Treatment=combatants$z, X=X2)

combatants$ebalw2=replicate(nrow(combatants),1)
combatants$ebalw2[combatants$z==0] =ebalout2$w

attitudes_34v5678_m5_high <- ivreg(zleftA ~ combat | z, weights=ebalw2, data=combatants)
attitudes_34v5678_m5_highLeft <- ivreg(zleftA ~ combat | z, weights=ebalw2, data=subset(combatants, HHleft==1))
attitudes_34v5678_m5_highRight <- ivreg(zleftA ~ combat | z, weights=ebalw2, data=subset(combatants, HHleft==0))

############################################
# EB2: Match on covariates
############################################
covs.names <- c("native", "HHincome", "HHideology", "Q47b", "secular", "traditional", "religious", "sephardic", "ashkenazi", "mixed", "USSR", "area1", "area2", "area3", "area4", "area5", "area6")
bout.orig <- MatchBalance(z_on_cov_formula, combatants)
options(digits=2)
bal.orig =baltest.collect(matchbal.out=bout.orig, var.names=covs.names,after=FALSE)

X_bal=combatants[covs.names]
ebalout <- ebalance(Treatment=combatants$z, X=X_bal)

combatants$ebalw=replicate(nrow(combatants),1)
combatants$ebalw[combatants$z==0] =ebalout$w

attitudes_34v5678_m6_high <- ivreg(zleftA ~ combat | z, weights=ebalw, data=combatants)
attitudes_34v5678_m6_highLeft <- ivreg(zleftA ~ combat | z, weights=ebalw, data=subset(combatants, HHleft==1))
attitudes_34v5678_m6_highRight <- ivreg(zleftA ~ combat | z, weights=ebalw, data=subset(combatants, HHleft==0))

# Balance after matching 
bout.ebal <- MatchBalance(z_on_cov_formula, data=combatants, weights=combatants$ebalw)
bal.ebal <- baltest.collect(matchbal.out=bout.ebal,var.names=covs.names,after=F)
xtable(bal.ebal, digits=3)

############################################
### Figure 10 (online appendix): 
### Robustness to Matching on covariates
############################################
all_ests_high <-  c(summary(attitudes_34v5678_high)$coefficients[2,1], summary(attitudes_34v5678_m6_high)$coefficients[2,1], summary(attitudes_34v5678_m2_high)$coefficients[2,1], summary(attitudes_34v5678_m4_high)$coefficients[2,1])
all_ests_highLeft <- c(summary(attitudes_34v5678_highLeft)$coefficients[2,1], summary(attitudes_34v5678_m6_highLeft)$coefficients[2,1], summary(attitudes_34v5678_m2_highLeft)$coefficients[2,1], summary(attitudes_34v5678_m4_highLeft)$coefficients[2,1])
all_ests_highRight <- c(summary(attitudes_34v5678_highRight)$coefficients[2,1], summary(attitudes_34v5678_m6_highRight)$coefficients[2,1], summary(attitudes_34v5678_m2_highRight)$coefficients[2,1], summary(attitudes_34v5678_m4_highRight)$coefficients[2,1])

all_ses_high <-  c(summary(attitudes_34v5678_high)$coefficients[2,2], summary(attitudes_34v5678_m6_high)$coefficients[2,2], summary(attitudes_34v5678_m2_high)$coefficients[2,2], summary(attitudes_34v5678_m4_high)$coefficients[2,2])
all_ses_highLeft <- c(summary(attitudes_34v5678_highLeft)$coefficients[2,2], summary(attitudes_34v5678_m6_highLeft)$coefficients[2,2], summary(attitudes_34v5678_m2_highLeft)$coefficients[2,2], summary(attitudes_34v5678_m4_highLeft)$coefficients[2,2])
all_ses_highRight <- c(summary(attitudes_34v5678_highRight)$coefficients[2,2],summary(attitudes_34v5678_m6_highRight)$coefficients[2,2], summary(attitudes_34v5678_m2_highRight)$coefficients[2,2], summary(attitudes_34v5678_m4_highRight)$coefficients[2,2])

pdf(file="figures/MatchingCovariates.pdf")
plot(NA, ylim=c(-1, 1), xlim=c(0,4), main="Unmatched vs. Matching on Covariates \n (2nd Intifada)", ylab="LATE of Combat on Reconciliation", xlab="Matching Type", xaxt="n")
axis(side=1, at=.5:3.5, labels=c("Unmatched","EB", "NN", "CEM"))
plotCI(.35:3.35, all_ests_highLeft, 
       ui=all_ests_highLeft + 1.645*all_ses_highLeft,
       li=all_ests_highLeft - 1.645*all_ses_highLeft,col="black", lwd=3, lty=1,
       add=TRUE)
plotCI(.65:3.65, all_ests_highRight, 
       ui=all_ests_highRight + 1.645*all_ses_highRight,
       li=all_ests_highRight - 1.645*all_ses_highRight, col="black", lwd=3, lty=5,
       add=TRUE)
abline(h=0, lty=2)
dev.off()


############################################
### Figure 9 (online appendix): 
### Robustness to different kinds of matching: Matching on combat propensity
############################################
all_ests_highP <-  c(summary(attitudes_34v5678_high)$coefficients[2,1], summary(attitudes_34v5678_m5_high)$coefficients[2,1], summary(attitudes_34v5678_m1_high)$coefficients[2,1], summary(attitudes_34v5678_m3_high)$coefficients[2,1])
all_ests_highLeftP <- c(summary(attitudes_34v5678_highLeft)$coefficients[2,1], summary(attitudes_34v5678_m5_highLeft)$coefficients[2,1], summary(attitudes_34v5678_m1_highLeft)$coefficients[2,1], summary(attitudes_34v5678_m3_highLeft)$coefficients[2,1])
all_ests_highRightP <- c(summary(attitudes_34v5678_highRight)$coefficients[2,1], summary(attitudes_34v5678_m5_highRight)$coefficients[2,1], summary(attitudes_34v5678_m1_highRight)$coefficients[2,1], summary(attitudes_34v5678_m3_highRight)$coefficients[2,1])

all_ses_highP <-  c(summary(attitudes_34v5678_high)$coefficients[2,2], summary(attitudes_34v5678_m5_high)$coefficients[2,2], summary(attitudes_34v5678_m1_high)$coefficients[2,2], summary(attitudes_34v5678_m3_high)$coefficients[2,2])
all_ses_highLeftP <- c(summary(attitudes_34v5678_highLeft)$coefficients[2,2], summary(attitudes_34v5678_m5_highLeft)$coefficients[2,2], summary(attitudes_34v5678_m1_highLeft)$coefficients[2,2], summary(attitudes_34v5678_m3_highLeft)$coefficients[2,2])
all_ses_highRightP <- c(summary(attitudes_34v5678_highRight)$coefficients[2,2],summary(attitudes_34v5678_m5_highRight)$coefficients[2,2], summary(attitudes_34v5678_m1_highRight)$coefficients[2,2], summary(attitudes_34v5678_m3_highRight)$coefficients[2,2])

pdf(file="figures/MatchingPropensity.pdf")
plot(NA, ylim=c(-1, 1), xlim=c(0,4), main="Unmatched vs. Matching on Combat Propensity \n (2nd Intifada)", ylab="LATE of Combat on Reconciliation", xlab="Matching Type", xaxt="n")
axis(side=1, at=.5:3.5, labels=c("Unmatched","EB", "NN", "CEM"))
plotCI(.35:3.35, all_ests_highLeftP, 
       ui=all_ests_highLeftP + 1.645*all_ses_highLeftP,
       li=all_ests_highLeftP - 1.645*all_ses_highLeftP,col="black", lwd=3, lty=1,
       add=TRUE)
plotCI(.65:3.65, all_ests_highRightP, 
       ui=all_ests_highRightP + 1.645*all_ses_highRightP,
       li=all_ests_highRightP - 1.645*all_ses_highRightP, col="black", lwd=3, lty=5,
       add=TRUE)
abline(h=0, lty=2)
dev.off()


	
pdf(file="figures/MatchingCovariatesPropesnity.pdf", width=12, height=9)
	deg=3
	par(mfrow=c(1,2))
plot(NA, ylim=c(-1, 1), xlim=c(0,4), main="Matching on Covariates", ylab="LATE of Combat on Reconciliation", xlab="Matching Type", xaxt="n")
axis(side=1, at=.5:3.5, labels=c("Unmatched","EB", "NN", "CEM"))
plotCI(.35:3.35, all_ests_highLeft, 
       ui=all_ests_highLeft + 1.645*all_ses_highLeft,
       li=all_ests_highLeft - 1.645*all_ses_highLeft,col="black", lwd=3, lty=1,
       add=TRUE)
plotCI(.65:3.65, all_ests_highRight, 
       ui=all_ests_highRight + 1.645*all_ses_highRight,
       li=all_ests_highRight - 1.645*all_ses_highRight, col="black", lwd=3, lty=5,
       add=TRUE)
abline(h=0, lty=2,  col="red")

plot(NA, ylim=c(-1, 1), xlim=c(0,4), main="Matching on Combat Propensity", ylab="LATE of Combat on Reconciliation", xlab="Matching Type", xaxt="n")
axis(side=1, at=.5:3.5, labels=c("Unmatched","EB", "NN", "CEM"))
plotCI(.35:3.35, all_ests_highLeftP, 
       ui=all_ests_highLeftP + 1.645*all_ses_highLeftP,
       li=all_ests_highLeftP - 1.645*all_ses_highLeftP,col="black", lwd=3, lty=1,
       add=TRUE)
plotCI(.65:3.65, all_ests_highRightP, 
       ui=all_ests_highRightP + 1.645*all_ses_highRightP,
       li=all_ests_highRightP - 1.645*all_ses_highRightP, col="black", lwd=3, lty=5,
       add=TRUE)
abline(h=0, lty=2,  col="red")
dev.off()

