
library(foreign)
library(xtable)
library(reporttools)


combatants <- read.dta("data/cleandata_combatants.dta")
exposure.high <- combatants[combatants$intifada==1,]
exposure.low <- combatants[combatants$intifada==0,]

############################################
# Descriptive Stats
# tables A.1 and A.2 in manuscript
############################################
attach(exposure.high)
dvs <- data.frame(Combat_eligibility=z, Combat_exposure=combat, Reconciliation_summary_index =zleftA, Support_negotiated_territorial_withdrawal=zQ16b, Support_negotiated_division_of_Jerusalem=zQ17b, 
                  Support_negotiated_refugee_right_of_return=zQ18b, Palestinians_are_partners_for_peace=zQ21b, Support_conciliatory_solutions=zQ23b, 
                  Israel_indivisible=zQ24b, Settlements_endanger_Israeli_democracy=zQ28b, Occupation_is_immoral=zQ29b, Oppose_limitations_on_human_right_NGOs=zQ30b, 
                  Right_Left_scale_self_placement=zQ33, Vote_choice_2013_elections=votechoice13, Vote_choice_first_election=firstvote,
                  Political_participation_index=zparticipationA, Political_interest=zQ35b, Party_membership=zQ36b, Demonstration=zQ37_1, 
                  Petition=zQ37_2, Advocacy_group=zQ37_3, Contact_public_official=zQ37_4, Radio_call=zQ37_5, Newspaper_comment=zQ37_6, Facebook_political_status=zQ37_7,
                  Framing_support_military_solutions=zQ26_1, Peer_effect_right_leaning_unit=peereffect1, 
                  Prejudice_summary_index=zprejudiceA, Intelligence_difference=zintelligent, Trustworthiness_difference=ztrustworthy, Altruism_difference=znonegoistic, 
                  Non_violence_difference=znonviolent,Palestinians_goal_Expel_Jews=zQ22b, Terror_attack=zQ32_1, Missiles_attack=zQ32_2,Existential_threat=zQ32_3)

tableContinuous(vars = dvs, stats = c("mean", "s", "min", "median","max", "n"),cap = "Descriptive Statistics: 2nd Intifada Sample (2000-2006)", lab = "tab:DescriptiveHIntensity")


ivs=data.frame(HH_income=HHincome, HH_ideology=HHideology, Native=native, Father_combatant=Q47b,  Secular=secular, Traditional=traditional, 
                 Religious=religious, Sephardic=sephardic, Ashkenazi=ashkenazi, Mixed_background=mixed, USSR=USSR, 
                 Jerusalem=area1, Norht=area2, Haifa=area3, Center=area4, Tel_Aviv=area5, South=area6, Territories=area7)

print(tableContinuous(vars = ivs, stats = c("mean", "s", "min", "median","max", "n"),cap = "Descriptive Statistics: 2nd Intifada Sample (2000-2006)"))


detach(exposure.high)
attach(exposure.low)
dvs <- data.frame(Combat_eligibility=z, Combat_exposure=combat, Reconciliation_summary_index =zleftA, Support_negotiated_territorial_withdrawal=zQ16b, Support_negotiated_division_of_Jerusalem=zQ17b, 
                  Support_negotiated_refugee_right_of_return=zQ18b, Palestinians_are_partners_for_peace=zQ21b, Support_conciliatory_solutions=zQ23b, 
                  Israel_indivisible=zQ24b, Settlements_endanger_Israeli_democracy=zQ28b, Occupation_is_immoral=zQ29b, Oppose_limitations_on_human_right_NGOs=zQ30b, 
                  Right_Left_scale_self_placement=zQ33, Vote_choice_2013_elections=votechoice13, Vote_choice_first_election=firstvote,
                  Political_participation_index=zparticipationA, Political_interest=zQ35b, Party_membership=zQ36b, Demonstration=zQ37_1, 
                  Petition=zQ37_2, Advocacy_group=zQ37_3, Contact_public_official=zQ37_4, Radio_call=zQ37_5, Newspaper_comment=zQ37_6, Facebook_political_status=zQ37_7,
                  Framing_support_military_solutions=zQ26_1, Peer_effect_right_leaning_unit=peereffect1, 
                  Prejudice_summary_index=zprejudiceA, Intelligence_difference=zintelligent, Trustworthiness_difference=ztrustworthy, Altruism_difference=znonegoistic, 
                  Non_violence_difference=znonviolent,Palestinians_goal_Expel_Jews=zQ22b, Terror_attack=zQ32_1, Missiles_attack=zQ32_2,Existential_threat=zQ32_3)

tableContinuous(vars = dvs, stats = c("mean", "s", "min", "median","max", "n"),cap = "Descriptive Statistics: Post-Gaza Withdrawal Sample (2007-2012)", lab = "tab:DescriptiveLIntensity")


ivs=data.frame(HH_income=HHincome, HH_ideology=HHideology, Native=native, Father_combatant=Q47b,  Secular=secular, Traditional=traditional, 
               Religious=religious, Sephardic=sephardic, Ashkenazi=ashkenazi, Mixed_background=mixed, USSR=USSR, 
               Jerusalem=area1, Norht=area2, Haifa=area3, Center=area4, Tel_Aviv=area5, South=area6, Territories=area7)

print(tableContinuous(vars = ivs, stats = c("mean", "s", "min", "median","max", "n"),cap = "Descriptive Statistics: Post-Gaza Withdrawal Sample (2007-2012)"))
detach(exposure.low)

############################################
# Balance table
# Table A.3 (manuscript))
############################################
attach(exposure.high)

vars = c("HHincome", "HHideology", "native", "Q47b", "secular", "traditional", "religious", "sephardic", "ashkenazi","mixed", "USSR", "area1", "area2", "area3", "area4", "area5", "area6", "area7")
fitsHigh <- matrix(NA, nrow=length(vars), ncol=5)
tpHigh<- matrix(NA, nrow=length(vars), ncol=1)

for(v in 1:length(vars)) {
  U=exposure.high[,vars[v]]
  tpHigh[v,] = t.test(U~z, var.equal=FALSE)$p.value
  fitsHigh[v,]=cbind(mean(U[z==0]), mean(U[z==1]), mean(U[z==1])-mean(U[z==0]), (mean(U[z==1])-mean(U[z==0]))/sd(U[z==1]), tpHigh[v,]) 
}       

colnames(fitsHigh) <- c("Below", "Above", "Diff", "std bias", "p.value")
rownames(fitsHigh) <- c("HH income", "HH ideology", "Native", "Father combatant", "Secular", "Traditional", "Religious", "Sephradic", "Ashkenazi", "Mixed race", "USSR", "Jerusalem", "North", "Haifa", "Center", "Tel Aviv",  "South", "Territories")
print(fitsHigh)

detach(exposure.high)
attach(exposure.low)

fitsLow <- matrix(NA, nrow=length(vars), ncol=5)
tpLow<- matrix(NA, nrow=length(vars), ncol=1)

for(v in 1:length(vars)) {
  U=exposure.low[,vars[v]]
  tpLow[v,] = t.test(U~z, var.equal=FALSE)$p.value
  fitsLow[v,]=cbind(mean(U[z==0]), mean(U[z==1]), mean(U[z==1])-mean(U[z==0]), (mean(U[z==1])-mean(U[z==0]))/sd(U[z==1]), tpLow[v,]) 
}       

colnames(fitsLow) <- c("Below", "Above", "Diff", "std bias", "p.value")
rownames(fitsLow) <- c("HH income", "HH ideology", "Native", "Father combatant", "Secular", "Traditional", "Religious", "Sephradic", "Ashkenazi", "Mixed race", "USSR", "Jerusalem", "North", "Haifa", "Center", "Tel Aviv",  "South", "Territories")
print(fitsLow)

detach(exposure.low)

BalanceT=cbind(fitsHigh, fitsLow)
print(xtable(BalanceT, digits=3))



