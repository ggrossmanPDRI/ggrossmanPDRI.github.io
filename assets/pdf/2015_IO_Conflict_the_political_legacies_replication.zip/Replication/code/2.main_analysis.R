### This code analyzes the data using the estimation strategy
### specifdied in the pre-analysis plan (no matching, no covariates adjustment)

library(foreign)
library(AER)
library(MatchIt)
library(stargazer)
library(ggplot2)
library(plyr)
library(grid)
library(xtable)

combatants <- read.dta("data/cleandata_combatants.dta")

# Define Dependent Variables 
#1:11 -- Attitudes
#12:13 -- vote
#14:23 -- Participation
#24:25 -- Socialization
#26:31 -- Prejudice
#31:32 -- Threat

dvs <- c("zleftA", "zQ16b", "zQ17b", "zQ18b", "zQ21b", "zQ23b", "zQ24b", "zQ28b", "zQ29b", "zQ30b", "zQ33",
         "votechoice13", "firstvote",
         "zparticipationA", "zQ35b", "zQ36b", "zQ37_1", "zQ37_2", "zQ37_3", "zQ37_4", "zQ37_5", "zQ37_6", "zQ37_7",
         "zQ26_1", "peereffect1", 
         "zprejudiceA", "zintelligent", "ztrustworthy", "znonegoistic", "znonviolent","zQ22b",
         "zQ32_1","zQ32_2","zQ32_3"
         )

# empty vectors to store results
coefs_all <- ses_all <- pval_all <- coefs_high <- ses_high <- pval_high <- coefs_low <- ses_low <- pval_low <- rep(NA, length(dvs))
iv_fits_all <- iv_fits_low <- iv_fits_high <- vector(mode="list", length=length(dvs))

### Estimate IVs for all DVs, among both high and low
for (i in 1:length(dvs)){
  iv_formula <- formula(paste0(dvs[i], "~ combat | z"))
  iv_fits_all[[i]] <- iv_fit_all <- ivreg(formula=iv_formula, data=subset(combatants, sample345678==1))  
  iv_fits_high[[i]] <- iv_fit_high <- ivreg(formula=iv_formula, data=subset(combatants, intifada==1 & sample345678==1))
  iv_fits_low[[i]] <- iv_fit_low <- ivreg(formula=iv_formula, data=subset(combatants, intifada==0 & sample345678==1))
  coefs_all[i] <- round(summary(iv_fit_all)$coefficients[2,1],5)
  ses_all[i] <- round(summary(iv_fit_all)$coefficients[2,2],5)
  pval_all[i] <- round(summary(iv_fit_all)$coefficients[2,4],5)
  coefs_high[i] <- round(summary(iv_fit_high)$coefficients[2,1],5)
  ses_high[i] <- round(summary(iv_fit_high)$coefficients[2,2],5)
  pval_high[i] <- round(summary(iv_fit_high)$coefficients[2,4],5)
  coefs_low[i] <- round(summary(iv_fit_low)$coefficients[2,1],5)
  ses_low[i] <- round(summary(iv_fit_low)$coefficients[2,2],5)
  pval_low[i] <- round(summary(iv_fit_low)$coefficients[2,4],5)
}


## Table 6 in the online appendix
dvs
idnum <- 1:34
attitudes <- as.numeric(idnum %in% 1:11) 
vote <- as.numeric(idnum %in% 12:13)
participation <- as.numeric(idnum %in% 14:23)
socialization <- as.numeric(idnum %in% 24:25)
prejudice <- as.numeric(idnum %in% 26:31)
threat <- as.numeric(idnum %in% 32:34)

labels <- c("Reconciliation\nsummary index","Support negotiated \nterritorial withdrawal", "Support negotiated \ndivision of Jerusalem","Support negotiated \nrefugee right of return", "Palestinians are \npartners for peace", 
            "Support conciliatory solutions\n(e.g., two states)", 
         "Israel indivisible","Settlements endanger\n Israeli democracy", "Occupation is \nimmoral / illegal", "Oppose limitations on \nhuman right NGOs","Right-Left scale \nself-placement",
            "Vote choice: \n(2013 elections)", "Vote choice: \n(first election)",
         "Political participation \ index","Political interest","Party membership","Demonstration","Petition","Advocacy group","Contact public official","Radio call","Newspaper comment","Facebook political status",
            "Framing: support \nmilitary solutions", "Peer effect: \nright-leaning unit",
            "Prejudice summary index","Intelligence\n(difference)","Trustworthiness\n(difference)","Altruism\n(difference)","Non-violence\n(difference)", "Palestinians' goal:\nExpel Jews",
         "Terror attack","Missiles attack", "Existential threat"
         )
labels2 <- c("Reconciliation summary index","Support negotiated territorial withdrawal", 
             "Support negotiated division of Jerusalem", "Support negotiated refugee right of return", "Palestinians are partners for peace", 
             "Support conciliatory solutions (two states)", "Israel indivisible","Settlements endanger Israeli democracy", "Occupation is immoral / illegal", "Oppose limitations on human right NGOs","Right-Left scale self-placement",
             "Vote choice: (2013 elections)", "Vote choice: (first election)",
             "Political participation index","Political interest","Party membership","Demonstration","Petition","Advocacy group","Contact public official","Radio call","Newspaper comment","Facebook political status",
             "Framing: support military solutions", "Peer effect: right-leaning unit",
            "Prejudice summary index","Intelligence (difference)","Trustworthiness (difference)","Altruism (difference)","Non-violence (difference)", "Palestinians' goal:Expel Jews",
            "Terror attack","Missiles attack", "Existential threat"
            )

group <- factor(idnum,levels=rev(seq(1:34)),labels=labels[34:1])
allmodels_all <- data.frame(group, coefs_all, ses_all, pval_all, idnum, attitudes, vote, participation, socialization, prejudice, threat)
allmodels_high <- data.frame(group, coefs_high, ses_high, pval_high, idnum, attitudes, vote, participation, socialization, prejudice, threat)
allmodels_low <- data.frame(group, coefs_low, ses_low, pval_low, idnum, attitudes, vote, participation, socialization, prejudice, threat)

allmodels_all <- within(allmodels_all, {pe <- coefs_all
                                          lb <- coefs_all + 1.645*ses_all
                                          ub <- coefs_all - 1.645*ses_all})
allmodels_high <- within(allmodels_high, {pe <- coefs_high
                                          lb <- coefs_high + 1.645*ses_high
                                          ub <- coefs_high - 1.645*ses_high})
allmodels_low <- within(allmodels_low, {pe <- coefs_low
                                          lb <- coefs_low + 1.645*ses_low
                                          ub <- coefs_low - 1.645*ses_low})

allests <- cbind(round(coefs_high,3), paste0("(",round(ses_high,3),")"), round(pval_high,3), 
                 round(coefs_low,3), paste0("(",round(ses_low,3),")"), round(pval_low,3))
rownames(allests) <- labels2
colnames(allests) <- c("Est", "SEs","Pval",  "Est", "SEs", "Pval")
xtable(allests, digits=3)

#########################
#########################
# create figures
#########################
#########################

##############################################################
### Figure 1 (Treatment Effects on reconcilation)
##############################################################

f1high = ggplot(data = subset(allmodels_high, attitudes==1), aes(x = group, y = pe, ymin = lb, ymax = ub))
f1high = f1high + geom_pointrange(width=.5, size=1, position = position_dodge(width=.5))
f1high = f1high + scale_shape_manual(values=c(22,22))  # as before
f1high = f1high + scale_fill_manual(values=c("black","black"))
f1high = f1high + coord_flip()
f1high = f1high + ylim(-1,1)
f1high = f1high + geom_hline(yintercept=0, linetype="longdash", size=1)
f1high = f1high + labs(y="Regression Coefficient", x="", title="Reconciliation: 2nd Intifada")
f1high = f1high+ theme_bw(base_size = 12, base_family = "Helvetica")
print(f1high)


f1low = ggplot(data = subset(allmodels_low, attitudes==1), aes(x = group, y = pe, ymin = lb, ymax = ub))
f1low = f1low + geom_pointrange(width=.5, size=1, position = position_dodge(width=.5))
f1low = f1low + scale_shape_manual(values=c(22,22))  # as before
f1low = f1low + scale_fill_manual(values=c("black","black"))
f1low = f1low + coord_flip()
f1low = f1low + ylim(-1,1)
f1low = f1low + geom_hline(yintercept=0, linetype="longdash", size=1)
f1low = f1low + labs(y="Regression Coefficient", x="", title="Reconciliation: Post-Gaza Withdrawal")
f1low = f1low + theme_bw(base_size = 12, base_family = "Helvetica")
print(f1low)

# create figure
pdf("figures/both_combat_attitudes.pdf", width=12, height=10)
grid.newpage()
pushViewport(viewport(layout=grid.layout(1,2)))

vplayout=function(x,y) viewport(layout.pos.row=x, layout.pos.col=y)
print(f1high, vp=vplayout(1,1))
print(f1low,  vp=vplayout(1,2))
dev.off()

##############################################################
### Figure 2 (Treatment Effects on voting behavior)
##############################################################

# high violence intensity
f2high = ggplot(data = subset(allmodels_high, vote==1), aes(x = group, y = pe, ymin = lb, ymax = ub))
f2high = f2high + geom_pointrange(width=.5, size=1, position = position_dodge(width=.5))
f2high = f2high + scale_shape_manual(values=c(22,22))  # as before
f2high = f2high + scale_fill_manual(values=c("black","black"))
f2high = f2high + coord_flip()
f2high = f2high + ylim(-2,0.5)
f2high = f2high + geom_hline(yintercept=0, linetype="longdash", size=1)
f2high = f2high + labs(y="Regression Coefficient", x="", title="Vote Choice: 2nd Intifada")
f2high = f2high+ theme_bw(base_size = 12, base_family = "Helvetica")
print(f2high)

# low violence intensity
f2low = ggplot(data = subset(allmodels_low, vote==1), aes(x = group, y = pe, ymin = lb, ymax = ub))
f2low = f2low + geom_pointrange(width=.5, size=1, position = position_dodge(width=.5))
f2low = f2low + scale_shape_manual(values=c(22,22))  # as before
f2low = f2low + scale_fill_manual(values=c("black","black"))
f2low = f2low + coord_flip()
f2low = f2low + ylim(-2,.5)
f2low = f2low + geom_hline(yintercept=0, linetype="longdash", size=1)
f2low = f2low + labs(y="Regression Coefficient", x="", title="Vote Choice: Post-Gaza Withdrawal")
f2low = f2low + theme_bw(base_size = 12, base_family = "Helvetica")
print(f2low)

pdf("figures/both_combat_voting.pdf", width=12, height=6)
grid.newpage()
pushViewport(viewport(layout=grid.layout(1,2)))

vplayout=function(x,y) viewport(layout.pos.row=x, layout.pos.col=y)
print(f2high, vp=vplayout(1,1))
print(f2low,  vp=vplayout(1,2))
dev.off()

##############################################################
### Figure 3 (Treatment Effects on Political Participation)
##############################################################

f3high = ggplot(data = subset(allmodels_high, participation==1), aes(x = group, y = pe, ymin = lb, ymax = ub))
f3high = f3high + geom_pointrange(width=.5, size=1, position = position_dodge(width=.5))
f3high = f3high + scale_shape_manual(values=c(22,22))  # as before
f3high = f3high + scale_fill_manual(values=c("black","black"))
f3high = f3high + coord_flip()
f3high = f3high + ylim(-1,1)
f3high = f3high + geom_hline(yintercept=0, linetype="longdash", size=1)
f3high = f3high + labs(y="Regression Coefficient", x="", title="Participation: 2nd Intifada")
f3high = f3high+ theme_bw(base_size = 12, base_family = "Helvetica")
print(f3high)

f3low = ggplot(data = subset(allmodels_low, participation==1), aes(x = group, y = pe, ymin = lb, ymax = ub))
f3low = f3low + geom_pointrange(width=.5, size=1, position = position_dodge(width=.5))
f3low = f3low + scale_shape_manual(values=c(22,22))  # as before
f3low = f3low + scale_fill_manual(values=c("black","black"))
f3low = f3low + coord_flip()
f3low = f3low +  ylim(-1,1)
f3low = f3low + geom_hline(yintercept=0, linetype="longdash", size=1)
f3low = f3low + labs(y="Regression Coefficient", x="", title="Participation: Post-Gaza Withdrawal")
f3low = f3low + theme_bw(base_size = 12, base_family = "Helvetica")
print(f3low)

pdf("figures/both_combat_participation.pdf", width=12, height=10)
grid.newpage()
pushViewport(viewport(layout=grid.layout(1,2)))

vplayout=function(x,y) viewport(layout.pos.row=x, layout.pos.col=y)
print(f3high, vp=vplayout(1,1))
print(f3low,  vp=vplayout(1,2))
dev.off()

##############################################################
### combatants: Second Moment RI
### Fig 7 (online appendix): Is there a reduction in variance?
##############################################################

#### Get vectors of observed outcomes and treatment assignment
y_obs <- with(combatants , zleftA[intifada==1 & sample345678==1])
z_obs <- with(combatants , z[intifada==1 & sample345678==1])

#### Get the observed difference in variances
var_treat_obs <- var(y_obs[z_obs==1])
var_control_obs <- var(y_obs[z_obs==0])

diff_in_var_obs <- var_treat_obs - var_control_obs

## This function fills in the unobserved potential outcomes, according to ate_guess.
## If ate_guess = 0, this is the sharp null hypothesis of no effect
hypothesizer <- function(y.obs, z.obs, ate_guess, mode="both"){
  y1 <- y.obs*z.obs + (y.obs + ate_guess)*(1-z.obs)
  y0 <- y.obs*(1-z.obs) + (y.obs - ate_guess)*(z.obs)
  if(mode=="both"){return(cbind(y1,y0))}
  if(mode=="y1"){return(y1)}
  if(mode=="y0"){return(y0)}
}

## This function takes a complete schedule of potential outcomes and a hypothetical treatment assignment, and makes a hypothetical outcome vector.
switcher <- function(y1, y0, z){
  y.sim <- y1*z + y0*(1-z)
  return(y.sim)
}

## This is just complete random assignment, where you assign m of n units to treatment.
complete.ra <- function(N,m){
  assign <- ifelse(1:N %in% sample(1:N,m),1,0)
  return(assign)
}

## Generate potential outcomes under sharp null
y1 <- hypothesizer(y.obs=y_obs, z.obs=z_obs, ate_guess=0, mode="y1")
y0 <- hypothesizer(y.obs=y_obs, z.obs=z_obs, ate_guess=0, mode="y0")


## Get the simulated differences in variances under sharp null
set.seed(10052013)
sims <- 5000
diff_in_var_sim <- rep(NA, sims)

for (i in 1:sims){
  z.sim <- complete.ra(length(y_obs), m=length(y_obs[z_obs==1]))
  y.sim <- switcher(y1, y0, z= z.sim)
  diff_in_var_sim[i] <- var(y.sim[z.sim==1]) - var(y.sim[z.sim==0])
}

## one tailed test:

mean(diff_in_var_sim < diff_in_var_obs)
# p = 0.0128

pdf("figures/varianceRI.pdf")
hist(diff_in_var_sim, main="Simulated Variances under Null", xlab="Simulated Variances")
abline(v=diff_in_var_obs, col="red")
legend("topright", lty=c(1), col="red", legend=c("Observed Diff-in-var = -0.19"))
dev.off()



