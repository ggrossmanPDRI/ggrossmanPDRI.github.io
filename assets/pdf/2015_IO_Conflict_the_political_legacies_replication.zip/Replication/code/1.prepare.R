### This code prepares the data for analysis
library(foreign)
library(lubridate)
library(car)

cleandata <- read.dta("data/field_combatants_clean.dta", convert.factors = F)
dim(cleandata)
head(cleandata)
names(cleandata)

#is.na(ReleaseDate) | is.na(votechoice13) |
# standardize the dependent variable (among intifada3==1)
# Create alternative treatment variable that only compares 3s to 4s

standardizer <- function(x, z) {
  standardized <- (x -  mean(x[z==0], na.rm=TRUE))/sd(x[z==0], na.rm=TRUE)
  return(standardized)
}

##remaining NA's in dataset
navars <- colnames(cleandata)[unique(which(is.na(cleandata), arr.ind=TRUE)[,2])]
navars

## impute median values for missing Qs.
for (i in 1:length(navars)){
  cleandata[which(is.na(cleandata[,navars[i]])), navars[i]] <- median(cleandata[,navars[i]], na.rm=TRUE)
}

cleandata <- within(cleandata, {
  
  # standardize variables
  zleftA <- standardizer(leftA, z)
  zQ16b <- standardizer(Q16b, z) # "Negotiated territorial withdrawal"
  zQ17b <- standardizer(Q17b, z) # "Negotiated devision of Jerusalem"
  zQ18b <- standardizer(Q18b, z) # "Negotiated refugee right of return"
  zQ21b <- standardizer(Q21b, z) # "Palestinians are partners for peace"
  zQ23b <- standardizer(Q23b, z) # "Support conciliatory policies"
  zQ24b <- standardizer(Q24b, z) # "Israel indivisible"
  zQ28b <- standardizer(Q28b, z) # "Settlements endanger Israeli democracy"
  zQ29b <- standardizer(Q29b, z) # "Occupation is illegal/immoral"
  zQ30b <- standardizer(Q30b, z) # "Oppose limitations on NGOs"
  zQ33  <- standardizer(Q33, z) # "Dove-Hawk self-identification scale"
  
  zparticipationA <- standardizer(participationA, z)
  zQ35b <- standardizer(Q35b, z) # "Interest in politics" 
  zQ36b <- standardizer(Q36b, z) # "Party membership"
  zQ37_1 <- standardizer(Q37_1, z) # "Attended a demonstration" 
  zQ37_2 <- standardizer(Q37_2, z) # "Signed Petition" 
  zQ37_3 <- standardizer(Q37_3, z) # "Member of CSO"
  zQ37_4 <- standardizer(Q37_4, z) # "Contacetd public official"
  zQ37_5 <- standardizer(Q37_5, z) # "Comment in media outlet"
  zQ37_6 <- standardizer(Q37_6, z) # "Wrote talkback online" 
  zQ37_7 <- standardizer(Q37_7, z) # "Facebook political status"
  
  zQ26_1 <- standardizer(Q26_1, z) ## Framing: support Military solutions
  
  zprejudiceA <- standardizer(prejudiceA, z) #  "Prejudice summary index"
  zintelligent <- standardizer(intelligent, z) # "Intelligence (difference)"
  ztrustworthy <- standardizer(trustworthy, z) # "Trustworthiness (difference)"
  znonegoistic <- standardizer(nonegoistic, z) # "Altruism (difference)"
  znonviolent  <- standardizer(nonviolent, z) # "Non-violence (difference)"
  zQ22b <- standardizer(Q22b, z) # Expel Jews
  
  zQ32_1 <- standardizer(Q32_1, z) # "Terror attack fear" 
  zQ32_2 <- standardizer(Q32_2, z) # "Misslies attack fear"
  zQ32_3 <- standardizer(Q32_3, z) # "Existential threat"
  
  # specify windows
  sample345678 <- as.numeric(profile %in% c(3,4,5,6,7,8))
  sample3456 <- as.numeric(profile %in% c(3,4,5,6))
  
  # recode variables
  HHideology_factor <- recode(HHideology, "c(1,2,3)='Right'; c(4)='Center'; c(5,6,7) = 'Left'")
  HHincome_factor <- recode(HHincome, "c(1,2)='Low'; c(3)='Middle'; c(4,5) = 'High'")
  age_factor <- recode(age, "c(21,22,23,24)='Young'; c(25,26,27,28,29)='MiddleAged'; c(30,31,32,33) = 'Old'")
  release_year <- year(ReleaseDate)
  
}
)
  
keep <- c("age", "native", "HHincome", "HHideology", "Q47b", "secular", "traditional", 
          "religious", "haredi", "sephardic", "ashkenazi", "mixed", "USSR", "Jerusalem", 
          "North", "Center", "South", "Territories", "sdropout",
          "HHideology_factor","HHincome_factor", "age_factor", "release_year",
          "profile", "z", "combat", "combat2", "intifada", 
          "firstvote", "votechoice13", "zQ26_1", "peereffect1", 
          "zleftA", "zQ16b", "zQ17b", "zQ18b", "zQ21b", "zQ23b", "zQ24b", "zQ28b", "zQ29b", "zQ30b", "zQ33",
          "zparticipationA", "zQ35b", "zQ36b", "zQ37_1", "zQ37_2", "zQ37_3", "zQ37_4", "zQ37_5", "zQ37_6", "zQ37_7",
          "zprejudiceA", "zintelligent", "ztrustworthy", "znonegoistic", "znonviolent",  "zQ22b",
          "zQ32_1","zQ32_2","zQ32_3",
          "sample345678", "sample3456", "Q52_56_1", "Q52_56_2", "Q52_56_3", "Q52_56_4", "Q52_56_5",
          "area1", "area2", "area3", "area4", "area5", "area6", "area7")

# keep only important vars
cleandata <- cleandata[,keep]

dim(cleandata)
table(cleandata$intifada)

write.dta(cleandata, file="data/cleandata_combatants.dta")


