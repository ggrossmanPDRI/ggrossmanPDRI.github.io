### Table 9 (online appendix): alternative treatment measure
### Measure: a binary variable indicating whether respondents participated in at least one of the major combat operations that took place between 2000-2006.

library(foreign)
library(AER)
library(stargazer)
library(xtable)

combatants <- read.dta("data/cleandata_combatants.dta")
names(combatants)

# subset to 2nd Intifada period (2000-2006)
combatants=combatants[combatants$intifada==1,]
combatants$HHleft <- as.numeric(combatants$HHideology > median(combatants$HHideology, na.rm=TRUE))
table(combatants$HHleft)

# correlation between alternative measures of combat
cor(combatants$combat, combatants$combat2)

dvs <- c("zleftA", "votechoice13", "zparticipationA", "zQ26_1", "peereffect1", "zprejudiceA", "zQ32_1", "zQ32_2", "zQ32_3")

# empty vectors to store results
coefs_all <- ses_all <- pval_all <- coefs_left <- ses_left <- pval_left <- coefs_right <- ses_right <- pval_right <- rep(NA, length(dvs))
iv_fits_all <- iv_fits_right <- iv_fits_left <- vector(mode="list", length=length(dvs))

### Estimate IVs for all DVs, among both left and right
for (i in 1:length(dvs)){
  iv_formula <- formula(paste0(dvs[i], "~ combat2 | z"))
  iv_fits_all[[i]] <- iv_fit_all <- ivreg(formula=iv_formula, data=subset(combatants, sample345678==1))  
  iv_fits_left[[i]] <- iv_fit_left <- ivreg(formula=iv_formula, data=subset(combatants, HHleft==1 & sample345678==1))
  iv_fits_right[[i]] <- iv_fit_right <- ivreg(formula=iv_formula, data=subset(combatants, HHleft==0 & sample345678==1))
  coefs_all[i] <- round(summary(iv_fit_all)$coefficients[2,1],5)
  ses_all[i] <- round(summary(iv_fit_all)$coefficients[2,2],5)
  pval_all[i] <- round(summary(iv_fit_all)$coefficients[2,4],5)
  coefs_left[i] <- round(summary(iv_fit_left)$coefficients[2,1],5)
  ses_left[i] <- round(summary(iv_fit_left)$coefficients[2,2],5)
  pval_left[i] <- round(summary(iv_fit_left)$coefficients[2,4],5)
  coefs_right[i] <- round(summary(iv_fit_right)$coefficients[2,1],5)
  ses_right[i] <- round(summary(iv_fit_right)$coefficients[2,2],5)
  pval_right[i] <- round(summary(iv_fit_right)$coefficients[2,4],5)
}

## Make Table
dvs
idnum <- 1:9
outcomes <- as.numeric(idnum %in% 1:3) 
mechanisms <- as.numeric(idnum %in% 2:9) 

labels <- c("Reconciliation\nsummary index",
            "Vote choice: \n(2013 elections)", 
            "Political participation \nsummary index",
            "Framing: support \nmilitary solutions", 
            "Peer effect: \nright-leaning unit",
            "Prejudice summary index", 
            "Terror attack","Missiles attack", "Existential threat"
)

labels2 <- c("Reconciliation summary index",
             "Vote choice: (2013 elections)", 
             "Political participation index",
             "Framing: support military solutions", 
             "Peer effect: right-leaning unit",
             "Prejudice summary index",
             "Terror attack","Missiles attack", "Existential threat"
)

group <- factor(idnum,levels=rev(seq(1:9)),labels=labels[9:1])
allmodels_all <- data.frame(group, coefs_all, ses_all, pval_all, idnum, outcomes, mechanisms)
allmodels_left <- data.frame(group, coefs_left, ses_left, pval_left, idnum, outcomes, mechanisms)
allmodels_right <- data.frame(group, coefs_right, ses_right, pval_right, idnum, outcomes, mechanisms)

allmodels_all <- within(allmodels_all, {pe <- coefs_all
                                        lb <- coefs_all + 1.645*ses_all
                                        ub <- coefs_all - 1.645*ses_all})
allmodels_left <- within(allmodels_left, {pe <- coefs_left
                                          lb <- coefs_left + 1.645*ses_left
                                          ub <- coefs_left - 1.645*ses_left})
allmodels_right <- within(allmodels_right, {pe <- coefs_right
                                            lb <- coefs_right + 1.645*ses_right
                                            ub <- coefs_right - 1.645*ses_right})

allests <- cbind(round(coefs_all,3), paste0("(",round(ses_all,3),")"), round(pval_all,3),
                 round(coefs_left,3), paste0("(",round(ses_left,3),")"), round(pval_left,3), 
                 round(coefs_right,3), paste0("(",round(ses_right,3),")"), round(pval_right,3))

rownames(allests) <- labels2
colnames(allests) <- c("Est", "SEs","Pval", "Est", "SEs","Pval","Est", "SEs", "Pval")
print(xtable(allests, digits=3))
